//
//  AnimationSeries.h
//  AnimationSeries
//
//  Created by ParkHyunsoo on 17/02/2019.
//  Copyright © 2019 ParkHyunsoo. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AnimationSeries.
FOUNDATION_EXPORT double AnimationSeriesVersionNumber;

//! Project version string for AnimationSeries.
FOUNDATION_EXPORT const unsigned char AnimationSeriesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AnimationSeries/PublicHeader.h>


